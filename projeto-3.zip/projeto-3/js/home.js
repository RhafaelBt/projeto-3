document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('accessToken');

  if (!token) {
    alert('Você precisa estar logado para acessar esta página!');
    window.location.href = './login.html';
    return;
  }

  try {
    const response = await fetch('http://projetoweb-api.vercel.app/auth/login', {
      method: 'GET',
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await response.json();

    if (!response.ok || !data.valid) {
      throw new Error(data.message || 'Token inválido');
    }

    document.getElementById('nomeUsuario').textContent = data.nome;
    document.getElementById('emailUsuario').textContent = data.email;
  } catch (error) {
    alert(error.message);
    localStorage.removeItem('accessToken');
    window.location.href = './login.html';
  }
});

document.getElementById('sair').addEventListener('click', () => {
  localStorage.removeItem('accessToken');
  window.location.href = './login.html';
});
