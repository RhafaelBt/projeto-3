document.querySelector('#formCadastro').addEventListener('submit', function (event) {
  event.preventDefault();


  const nome = document.querySelector('#nome').value;
  const email = document.querySelector('#email').value;
  const senha = document.querySelector('#senha').value;


  if (!nome || !email || !senha) {
    alert('Por favor, preencha todos os campos.');
    return;
  }

  
  const senhaValida = /^(?=.*[a-zA-Z])(?=.*[0-9]).{8,}$/;
  if (!senhaValida.test(senha)) {
    alert('a senha deve ter pelo menos 8 caracteres e incluir letras e números.');
    return;
  }

  
  const usuario = { nome, email, senha };
  localStorage.setItem('usuario', JSON.stringify(usuario));

  alert('Cadastro realizado com sucesso!');
  window.location.href = 'index.html'; 
});
