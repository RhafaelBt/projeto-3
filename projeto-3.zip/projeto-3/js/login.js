
document.querySelector('#formLogin').addEventListener('submit', function (event) {
  event.preventDefault(); 

  
  const email = document.querySelector('#email').value;
  const senha = document.querySelector('#senha').value;

  if (!email || !senha) {
    alert('Por favor, preencha todos os campos.');
    return;
  }


  const usuario = JSON.parse(localStorage.getItem('usuario'));

  if (!usuario || usuario.email !== email || usuario.senha !== senha) {
    alert('E-mail ou senha incorretos.');
    return;
  }

  alert(`Bem-vindo, ${usuario.nome}!`);
  window.location.href = 'home.html';
});
